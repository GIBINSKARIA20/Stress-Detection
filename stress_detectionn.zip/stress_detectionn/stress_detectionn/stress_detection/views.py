from django.http import HttpResponse
from django.shortcuts import render ,get_object_or_404
from django.shortcuts import redirect
from  django.core.files.storage import FileSystemStorage
from django.conf import settings
from .models import *
import pycurl
from urllib.parse import urlencode
#from ML import emotions_detection
#from ML.emotion_text import emotion_text

from keras import backend as K

def sends_mail(mail,msg):

	crl = pycurl.Curl()
	crl.setopt(crl.URL, 'https://alc-training.in/gateway.php')
	data = {'email': mail,'msg':msg}
	pf = urlencode(data)

	# Sets request method to POST,
	# Content-Type header to application/x-www-form-urlencoded
	# and data to send in request body.
	crl.setopt(crl.POSTFIELDS, pf)
	crl.perform()
	crl.close()

def first(request):
    return render(request,'index.html')



def index(request):
    return render(request,'index.html')
    
    
def reg(request):
    return render(request,'register.html')
    
    
def addreg(request):
    if request.method == 'POST':
        name = request.POST.get('name')
        email = request.POST.get('email')
        phone = request.POST.get('phone')
        password = request.POST.get('password')


        if register.objects.filter(email=email).exists():
            return render(request, 'register.html', {'status': 'Email already exists. Registration failed.'})
        else:
            user = register(name=name, email=email, phone=phone, password=password,status='pending')
            user.save()
            return render(request, 'register.html', {'status': 'Registration successful.'})

    return render(request, 'register.html')     

def aproveuser(request,id):
    user = get_object_or_404(register, id=id)
    user.status='approved'
    user.save()
    sel=register.objects.all()
    return render(request,'admin/user.html',{'res':sel})
 
def rejectuserrr(request,id):
    user = get_object_or_404(register, id=id)
    user.status='rejected'
    user.save()
    sel=register.objects.all()
    return render(request,'admin/user.html',{'res':sel})       
        
def logint(request):
    email = request. POST.get('email')
    password=request. POST.get('password')
    if email == 'admin@gmail.com' and password == 'admin':
        request.session['logintdetail'] = email
        request.session['logint'] = 'admin'
        return render(request, 'admin/index.html',{'status': 'LOGIN SUCCESSFULLY'})


    elif register.objects.filter(email=email,password=password,status='approved').exists():
        userdetails=register.objects.get(email=request.POST['email'], password=password)
        if userdetails.password == request.POST['password']:
            request.session['uid'] = userdetails.id
            request.session['sname'] = userdetails.name

            request.session['semail'] = email

            request.session['user'] = 'user'
            password = request.POST.get('password')

            
            return render(request,'index.html',{'status': 'LOGIN SUCCESSFULLY'})  
    
    elif doctor.objects.filter(email=email,password=password).exists():
        userdetails=doctor.objects.get(email=request.POST['email'], password=password)
        if userdetails.password == request.POST['password']:
            request.session['did'] = userdetails.id
            request.session['tname'] = userdetails.name

            request.session['temail'] = email

            request.session['doctor'] = 'doctor'


            return render(request,'index.html',{'status': 'LOGIN SUCCESSFULLY'})            


            
    
    else:
        return render(request, 'login.html', {'status': 'INVALID USERID OR PASSWORD'})   


def login(request):
    return render(request,'login.html')
    
def logout(request):
    session_keys = list(request.session.keys())
    for key in session_keys:
        del request.session[key]
    return redirect(first) 
    
def forget(request):
    return render(request,'forgetpass.html') 

def forgetpassword(request):
    if request.method == "POST":
        entered_email = request.POST.get('email')

        # Check if the entered email exists in the regtable (User model)
        try:
            user = register.objects.get(email=entered_email)
            password = user.password  # Retrieve the password from the User model

            # Send the password to the user's email using the sends_mail function
            message = f'Your password For login is: {password}'
         
            sends_mail(entered_email, message)

            return render(request, 'login.html', {'msg': 'Your password has been sent to the registered email.'})

        except register.DoesNotExist:
            return render(request, 'login.html', {'msg': 'Entered email does not exist .'})

    return render(request, 'login.html', {'msg': 'Enter your registered email to recover your password.'})     
   
    







def userview(request):
     sel=register.objects.all()
     return render(request,'admin/user.html',{'res':sel})
     
def dash(request):
    return render(request,'admin/index.html')
    
''''def addup(request,id):

    sel=remedy.objects.get(pk=id)
          
    sel.save()
        return redirect(viewstress)
    return render(request,'admin/update.html',{'res':sel})'''

def update(request,id):
        request.session['emotion_id']=id
        return render(request,'admin/update.html')
        
        





def viewuser(request):
    upd=remedy.objects.all()
    return render(request,'viewremedies.html',{'res':upd})
def adddoctor(request):
    return render(request,'admin/adddoctor.html',{'status': 'SUCCESSFULLY ADDED'})   
def viewuserdoctor(request):
    sel=doctor.objects.all()
    return render(request,'viewuserdoctor.html',{'result':sel})

       
  

def addd(request):
    if request.method=="POST":
        name=request.POST.get('name')
        email=request.POST.get('email')
        phone=request.POST.get('phone')
        address=request.POST.get('address')
        password=request.POST.get('password')
        age=request.POST.get('age')
        specialization=request.POST.get('specialization')
        experience=request.POST.get('experience')

        donor=doctor(specialization=specialization,experience=experience,name=name,email=email,phone=phone,address=address,password=password,age=age)
        donor.save()
        return render(request,'adddoctor.html',{'status':' Successfully Added'})
    
def viewuserdoctor(request):
    sel=doctor.objects.all()
    return render(request,'viewuserdoctor.html',{'result':sel})